RegisterNetEvent("esx:setJob")
AddEventHandler("esx:setJob", function(job)
    lib.func.updateNUI('job', job)
end)

RegisterNetEvent("esx:setHiddenJob")
AddEventHandler("esx:setHiddenJob", function(job)
    lib.func.updateNUI('hiddenjob', job)
end)

RegisterNetEvent('esx:playerLoaded')
AddEventHandler('esx:playerLoaded', function(xPlayer)
    lib.func.updateNUI('job', xPlayer.job)
    lib.func.updateNUI('hiddenjob', xPlayer.hiddenjob)
end)

AddStateBagChangeHandler('counter', 'global', function(name, key, value)
    lib.func.updateNUI('counter', value)
end)

AddStateBagChangeHandler('using', 'global', function(name, key, value)
    lib.cache.using = value
end)

RegisterCommand('+scoreboard', function()
    lib.func.globalThread(true)
end, false)

RegisterCommand('-scoreboard', function()
    lib.func.globalThread(false)
end, false)

RegisterKeyMapping('+scoreboard', 'Lista graczy', 'keyboard', 'Z')

function PlayerList()

	if IsNuiActive then
		return
	end

	local timer = GetGameTimer()
	if timer - Timer > 10000 then
		Timer, Id, MisiaczekPlayers = timer, nil, nil, {}
		TriggerServerEvent('esx_scoreboard:players')
	end
	
	if Id and PlayerData.job then
		SendNUIMessage({
			action = 'updatePlayerJobs',
			jobs   = {ems = MisiaczekPlayers['ambulance'], police = MisiaczekPlayers['police'], sheriff = MisiaczekPlayers['sheriff'], mechanik = MisiaczekPlayers['mechanik'], doj = MisiaczekPlayers['doj'], player_count = MisiaczekPlayers['players']}
		})
		
		SendNUIMessage({
			action = 'toggle',
			state = true
		})

		SendNUIMessage({
            action = "updateCode", 
            code = exports['esx_napierdalankachat']:czytajkod()
        })
		
		IsNuiActive = true
	end
end

RegisterNetEvent('esx_scoreboard:players')
AddEventHandler('esx_scoreboard:players', function(Counter, Admin)
	Id = GetPlayerServerId(PlayerId())
	
	SendNUIMessage({
		action = 'updateId',
		id = Id
	})	
	
	MisiaczekPlayers = Counter
	StanMiasta = kod
	IsAdmin = Admin
end)