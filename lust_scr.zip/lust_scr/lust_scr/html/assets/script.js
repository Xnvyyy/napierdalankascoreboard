window.addEventListener('message', function(event) {
    switch(event.data.action) {
        case 'toggle':
            if (event.data.state) {
                $('#page').fadeIn('fast');
            } else {
                $('#page').fadeOut('fast');
            }
            break;
        case 'update':
            Object.entries(event.data.data).forEach(([type, info]) => {
                if (type == "players") {
                    $(`.${type}`).html(`<b>${info}</b>`);
                } else {
                    if (type != "admins") {
                        if (type != "job" && type != "hiddenjob") {
                            if (info > 0) {
                                $(`.${type}`).css("color", "yellowgreen");
                            } else {
                                $(`.${type}`).css("color", "crimson");
                            }
                        } 
                        $(`.${type}`).html(info);
                    } else {
                        $(`.${type}`).html(`<b style='color:#8cdc24;'>${info}</b>`)
                    }

                    // Additional switch cases for updating color based on specified cases
                }
            });
            break;
        case 'updateCode':
            $('#kod').html(`<span style="color: white">${event.data.code}</span>`);
            break;
    }
});
