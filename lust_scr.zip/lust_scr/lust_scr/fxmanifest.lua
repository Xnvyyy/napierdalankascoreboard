fx_version 'cerulean'
game 'gta5'
lua54 'yes'

author 'Ven'
description 'FiveM Scoreboard made for FrostRP'

client_scripts {
    'client/functions.lua',
    'client/main.lua',
    'client/lib.lua'
}

server_scripts {
    'server/functions.lua',
    'server/main.lua'
}

files {
    'html/assets/*.*',
    'html/index.html'
}

server_exports {
    'CounterPlayers',
	'MisiaczekPlayers',
}

ui_page 'html/index.html'

